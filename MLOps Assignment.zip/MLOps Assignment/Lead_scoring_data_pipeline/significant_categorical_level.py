list_platform = ['Level0', 'Level3', 'Level7', 'Level1', 'Level2', 'Level8']

list_medium = ['Level0', 'Level2', 'Level6', 'Level3', 'Level4', 'Level9', 
               'Level11', 'Level5', 'Level8', 'Level20', 'Level13', 'Level30', 
               'Level33', 'Level16', 'Level10', 'Level15', 'Level26', 'Level43']

list_source = ['Level2', 'Level0', 'Level7', 'Level4', 'Level6', 'Level16', 
               'Level5', 'Level14']
